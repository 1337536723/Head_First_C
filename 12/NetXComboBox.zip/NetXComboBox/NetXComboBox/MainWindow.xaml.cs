﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NetXComboBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<SomethingHere> collection
        {
            get
            {
                return new ObservableCollection<SomethingHere>()
            {
                new SomethingHere(true, "this"),
                new SomethingHere(false, "does"),
                new SomethingHere(false, "not"),
                new SomethingHere(true, "work")
            };
            }
            set
            {
                Console.WriteLine("UPDATED");
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
        }
    }
}
public class SomethingHere : INotifyPropertyChanged
{
    private bool _checked;
    public bool Checked
    {
        get { return _checked; }
        set
        {
            _checked = value;
            // Call OnPropertyChanged whenever the property is updated
            OnPropertyChanged("Checked");

            Console.WriteLine("Updated");
            }
        }

    private string _text;

    public event PropertyChangedEventHandler PropertyChanged;

    public string Text
    {
        get { return _text; }
        set
        {
            _text = value;
            // Call OnPropertyChanged whenever the property is updated
            OnPropertyChanged("Text");
        }
    }

    // Create the OnPropertyChanged method to raise the event
    protected void OnPropertyChanged(string name)
    {
        PropertyChangedEventHandler handler = PropertyChanged;
        if (handler != null)
        {
            handler(this, new PropertyChangedEventArgs(name));
        }
    }


    public SomethingHere(bool a, string b)
    {
        Checked = a;
        Text = b;
    }


}